package com.tutorials.ximexmobi;

import static org.mockito.Mockito.verify;

import com.google.firebase.auth.PhoneAuthOptions;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class RegisterTest {

   /* public static final String CELL_NUM_ID = "0642877576";

    // region constants ---------------------------------------------------------------------------

    // endregion constants ------------------------------------------------------------------------

    // region helper fields ------------------------------------------------------------------------

    // endregion helper fields ---------------------------------------------------------------------
    @Mock
    PhoneAuthOptions mPhoneAuthOptionsMock;

////
    Register SUT;

    @Before
    public void setup() throws Exception {
        SUT = new Register(mPhoneAuthOptionsMock);

    }

    // correct parameters passed to endpoint

    @Test
    public void registerUser_correctParametersPassedToEndpoint_successReturned() throws Exception {
        // Arrange
        // Act
        SUT.registerUser(CELL_NUM_ID);
        // Assert
        verify(mPhoneAuthOptionsMock).
    }

    // endpoint success success returned
    // endpoint failure failure return
    // endpoint general error failure returned
    // network error network error returned

    // region helper methods -----------------------------------------------------------------------

    // endregion helper methods --------------------------------------------------------------------

    // region helper classes -----------------------------------------------------------------------

    // endregion helper classes --------------------------------------------------------------------*/

}