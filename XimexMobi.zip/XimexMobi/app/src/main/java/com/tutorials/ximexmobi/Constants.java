package com.tutorials.ximexmobi;

import androidx.appcompat.app.AppCompatActivity;

public class Constants extends AppCompatActivity {
    public static final String XIMEX_USERS_REF = "Ximexusers";
}
