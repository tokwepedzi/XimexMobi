package com.tutorials.ximexmobi;

import static com.tutorials.ximexmobi.Constants.XIMEX_USERS_REF;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.tutorials.ximexmobi.adapters.PlacesAUtoCompleteAdapter;
import com.tutorials.ximexmobi.databinding.ActivitySubmitUserInfoBinding;
import com.tutorials.ximexmobi.models.XimexUser;

import org.w3c.dom.Text;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserInfo extends AppCompatActivity {
    public static final String TAG ="UserInfoActvty";
    private ActivitySubmitUserInfoBinding binding;
    private FirebaseFirestore firebaseFirestoreRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_user_info);

            //----------------------------------BIND VIEWS------------------------------------------
        binding =ActivitySubmitUserInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        final CircleImageView mProfPic = binding.profFic;
        final ImageView mTakePhotoCam = binding.editPicCam;
        final TextInputEditText mUserFullname = binding.userName;
        final TextInputEditText mCellnumber = binding.cellNumber;
        final AutoCompleteTextView mSuburbAutoComplete = binding.suburb;
        final TextInputEditText mEmailAddress = binding.email;
        final ImageButton mSubmitButton = binding.submitUserInfoBtn;

        mSuburbAutoComplete.setAdapter(new PlacesAUtoCompleteAdapter(UserInfo.this, android.R.layout.simple_expandable_list_item_1));

            //--------------------------DATABASE AND REFS-------------------------------------------
        firebaseFirestoreRef = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        DocumentReference XimexUserRef = firebaseFirestoreRef.collection(XIMEX_USERS_REF)
                .document(mAuth.getCurrentUser().getUid());

            //---------------------------GET USER FROM FIRESTORE------------------------------------
        XimexUserRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                XimexUser ximexUser = new XimexUser();
                DocumentSnapshot documentSnapshot = task.getResult();
                ximexUser = documentSnapshot.toObject(XimexUser.class);
                    //Update fields with corresponding user details
                mUserFullname.setText(ximexUser.getFullname());
                mCellnumber.setText(ximexUser.getCallsnumber());
                mSuburbAutoComplete.setText(ximexUser.getSurburb());
                mEmailAddress.setText(ximexUser.getEmail());

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d(TAG, "onGetXimexUserInfoFailure: "+e.getMessage());

            }
        });

            // Save Updated user details to firestore
        mSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //  check  that no fields are empty
                if(!validateFullNameInput()){
                    return;
                }else {

                }

            }
        });


    }


    //-------------------------------------METHODS TO VALIDATE INPUT FIELDS-------------------------
    private boolean validateFullNameInput(){
        String val = binding.userName.getEditableText().toString();
        if(val.isEmpty()){
            binding.userName.setError("Filed cannot be empty");
            return false;
        }else {
            binding.userName.setError(null);
            return true;
        }

    }
}